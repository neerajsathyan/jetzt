<!DOCTYPE html>
<html lang="de" class="no-js is-backscroll ">
  <head>
    
  <meta charset="utf-8" />
  <script type="text/javascript">
    !function () { var e = function () { var e, t = "__tcfapiLocator", a = [], n = window; for (; n;) { try { if (n.frames[t]) { e = n; break } } catch (e) { } if (n === window.top) break; n = n.parent } e || (!function e() { var a = n.document, r = !!n.frames[t]; if (!r) if (a.body) { var i = a.createElement("iframe"); i.style.cssText = "display:none", i.name = t, a.body.appendChild(i) } else setTimeout(e, 5); return !r }(), n.__tcfapi = function () { for (var e, t = arguments.length, n = new Array(t), r = 0; r < t; r++)n[r] = arguments[r]; if (!n.length) return a; if ("setGdprApplies" === n[0]) n.length > 3 && 2 === parseInt(n[1], 10) && "boolean" == typeof n[3] && (e = n[3], "function" == typeof n[2] && n[2]("set", !0)); else if ("ping" === n[0]) { var i = { gdprApplies: e, cmpLoaded: !1, cmpStatus: "stub" }; "function" == typeof n[2] && n[2](i) } else a.push(n) }, n.addEventListener("message", (function (e) { var t = "string" == typeof e.data, a = {}; try { a = t ? JSON.parse(e.data) : e.data } catch (e) { } var n = a.__tcfapiCall; n && window.__tcfapi(n.command, n.version, (function (a, r) { var i = { __tcfapiReturn: { returnValue: a, success: r, callId: n.callId } }; t && (i = JSON.stringify(i)), e.source.postMessage(i, "*") }), n.parameter) }), !1)) }; e() }();
  </script>
  <script>
  window.dataLayer = window.dataLayer || [];
  window._sp_ = {
      config: {
        accountId: 348,
        propertyId: 318,
        baseEndpoint: "https://consent-cdn.jetzt.de",
        events: {
          onMessageChoiceSelect: function(choiceId, choiceTypeId) {
            window.dataLayer.push({
              event: 'cmp.choice',
              cmpChoice: {
                choiceId,
                choiceTypeId,
              },
            })
          },
          onMessageReceiveData: function(data) {
            data.messageId &&
              window.dataLayer.push({
                event: 'cmp.message',
                cmpMessage: {
                  messageId: data.messageId,
                  messageDescription: data.msgDescription,
                },
              })
          },
          onPrivacyManagerAction: function(action) {
            window.dataLayer.push({
              event: 'cmp.privacymanager.action',
              cmpPrivacyManagerAction: action,
            })
          },
        }
      }
    }
  </script>
  <script defer src="https://consent-cdn.jetzt.de/wrapperMessagingWithoutDetection.js"></script>
  <script>document.documentElement.classList.remove("no-js")</script>

    
    <title>Seite nicht gefunden</title>
    <link href="https://caching-production.jetzt.de/assets/ckghrc6290001c1y7qgrzbub7/apos-minified/anon-ckghrc6290001c1y7qgrzbub7.css" rel="stylesheet" />
    
  <script type="text/javascript">
    if (!('IntersectionObserver' in window)) {
        var script = document.createElement("script");
        script.src = "https://polyfill.io/v3/polyfill.min.js?flags=gated&features=Object.assign%2CIntersectionObserver";
        document.getElementsByTagName('head')[0].appendChild(script);
    }
  </script>
  <script type="text/javascript" async src="https://api.id.swmhdata.jetzt.de/js/id-service.js"></script>
  
<link rel="manifest" href="/manifest.json" />

  


  <link rel="dns-prefetch" href="//script.ioam.de" />
<link rel="preconnect" href="https://de.ioam.de" crossorigin />

<link rel="preload" href="https://caching-production.jetzt.de/assets/ckghrc6290001c1y7qgrzbub7/modules/my-apostrophe-assets/fonts/din-condensed/din-condensed.woff2" as="font" type="font/woff2" crossorigin />
<link rel="preload" href="https://caching-production.jetzt.de/assets/ckghrc6290001c1y7qgrzbub7/modules/my-apostrophe-assets/fonts/SZText/SZText-Regular.woff2" as="font" type="font/woff2" crossorigin />
<link rel="preload" href="https://caching-production.jetzt.de/assets/ckghrc6290001c1y7qgrzbub7/modules/my-apostrophe-assets/fonts/SZSans/SZSansDigital-Web-Regular.woff2" as="font" type="font/woff2" crossorigin />
<link rel="preload" href="https://caching-production.jetzt.de/assets/ckghrc6290001c1y7qgrzbub7/modules/my-apostrophe-assets/fonts/SZText/SZText-Bold.woff2" as="font" type="font/woff2" crossorigin />
<link rel="canonical" href="" />
  <meta name="viewport" content="width=device-width, initial-scale=1" id="metaViewport" />
  <meta name="robots" content="index,follow,noarchive,noodp" />
  <link rel="alternate" type="application/rss+xml" title="RSS Feed von jetzt.de" href="/alle_artikel.rss" />
  











  



  




<meta property="og:url" content="" />
<meta property="og:type" content="website" />
<meta property="og:title" content="" />


<meta name="twitter:site" content="@JETZT" />
  <meta property="og:site_name" content="jetzt.de" />
  <meta property="og:locale" content="de_DE" />
  <meta property="fb:pages" content="118828385583" />
  <meta property="fb:page_id" content="118828385583" />
      <meta name="apple-mobile-web-app-capable" content="yes">
    <link href="/images/splashscreens/iphone5_splash.png" media="(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image">
    <link href="/images/splashscreens/iphone6_splash.png" media="(device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image">
    <link href="/images/splashscreens/iphoneplus_splash.png" media="(device-width: 621px) and (device-height: 1104px) and (-webkit-device-pixel-ratio: 3)" rel="apple-touch-startup-image">
    <link href="/images/splashscreens/iphonex_splash.png" media="(device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3)" rel="apple-touch-startup-image">
    <link href="/images/splashscreens/iphonexr_splash.png" media="(device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image">
    <link href="/images/splashscreens/iphonexsmax_splash.png" media="(device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3)" rel="apple-touch-startup-image">
    <link href="/images/splashscreens/ipad_splash.png" media="(device-width: 768px) and (device-height: 1024px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image">
    <link href="/images/splashscreens/ipadpro1_splash.png" media="(device-width: 834px) and (device-height: 1112px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image">
    <link href="/images/splashscreens/ipadpro3_splash.png" media="(device-width: 834px) and (device-height: 1194px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image">
    <link href="/images/splashscreens/ipadpro2_splash.png" media="(device-width: 1024px) and (device-height: 1366px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#000000">
    <meta name="apple-mobile-web-app-title" content="jetzt.de">
    <meta name="application-name" content="jetzt.de">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#000000">

    
    
  
  <!-- Google Tag Manager -->
  <script>
    window.dataLayer = window.dataLayer || [];
    if (window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true) {
      window.dataLayer.push({ pwa: 'yes' });
    } else {
      window.dataLayer.push({ pwa: 'no' });
    }
  </script>
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
  'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer','GTM-T4K79X');</script>
  <!-- End Google Tag Manager -->

  <script>
  (function() {
    window.mqIdent = window.matchMedia('only screen and (max-width: 767px)').matches
      ? 'mobile'
      : window.matchMedia('only screen and (max-width: 1280px)').matches
        ? 'tablet'
        : 'desktop';
  })();
</script>
<script>
  function IQSLoader(url) {
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;
    document.getElementsByTagName('head')[0].appendChild(script);
  }
  var iqd_mode = (function() {
    var dm = window.location.href.toLowerCase();
    return(dm.indexOf('iqdeployment=') > 1) ? dm.split('iqdeployment=')[1].split('&')[0] : 'live';
  })();
  var mqIdent = window.matchMedia('only screen and (max-width: 767px)').matches
    ? 'mobile'
    : window.matchMedia('only screen and (max-width: 1280px)').matches
      ? 'tablet'
      : 'desktop';
  var iqd_mandator = (mqIdent === 'tablet' || mqIdent === 'mobile') ? 'cdn_jde_mob_digt' : 'cdn_jde_digt';

  IQSLoader(
    'https://iqdtms.jetzt.de/' + iqd_mandator + '/' + iqd_mode + '/iqadcontroller.js.gz'
  );
</script>
<script>
  (function() {
    window.AdController = {
      i: null,
      q: [],
      f: false,
      s: false,
      n: false,
      r: null,
      c: [],
      setPageInfo: function(i) {
        window.AdController.i = i;
      },
      stage: function() {
        window.AdController.s = true;
      },
      initialize: function() {
        window.AdController.n = true;
      },
      render: function(n, c) {
        window.AdController.q.push([n, c]);
      },
      finalize: function() {
        window.AdController.f = true;
      },
      ready: function(callback) {
        window.AdController.r = callback;
      },
      startLoadCycle: function() {
        window.AdController.c.push(['startLoadCycle']);
      },
      reload: function(p, t) {
        window.AdController.c.push(['reload', p, t]);
      },
      reinitialize: function(i) {
        window.AdController.c.push(['reinitialize', i]);
      }
    };
  })();
</script>
<script>
  if (typeof AdController !== 'undefined') {
    var handle;
    var tag = "";
    var keywords = "";
    var tmaTag = "";
    var pageType = "";

    switch(pageType) {
      case "home":
        handle = "homepage";
        break;
      case "tagPage":
        handle = "index";
        tag = "";
        tmaTag = "";
        break;
      default:
        handle = "artikel";
        tag = "";
        tmaTag = ""
    }

    tag = tag.replace(/['\u00dc'-'\u00c4'-'\u00d6'-'\u00fc'-'\u00e4'-'\u00f6'-'\u00df']/g, function (m) {
      return {
        '\u00dc': 'UE',
        '\u00c4': 'AE',
        '\u00d6': 'OE',
        '\u00fc': 'ue',
        '\u00e4': 'ae',
        '\u00f6': 'oe',
        '\u00df': 'ss'
      }[m];
    })
    tmaTag = tmaTag.replace(/['\u00dc'-'\u00c4'-'\u00d6'-'\u00fc'-'\u00e4'-'\u00f6'-'\u00df']/g, function (m) {
      return {
        '\u00dc': 'UE',
        '\u00c4': 'AE',
        '\u00d6': 'OE',
        '\u00fc': 'ue',
        '\u00e4': 'ae',
        '\u00f6': 'oe',
        '\u00df': 'ss'
      }[m];
    })

    keywords = "";
    tag = tag.toLowerCase();
    tmaTag = tmaTag.toLowerCase()

    AdController.setPageInfo({
      $handle: handle,
      $autoSizeFrames: true,
      level2: tag,
      level3: "",
      keywords: keywords,
      tma: tmaTag,
    });
    try {
      AdController.stage();
    } catch(e) {}
    AdController.initialize();
  }
</script>

  <script>
  function createAd(desktopTileId, desktopInitRenderCall, mobileTileId, mobileInitRenderCall) {
    var adPosition = document.getElementById('ad__template--' + (desktopTileId || mobileTileId));

    function createAdTile(tileId, initRenderCall) {
      var adTileId = 'iqadtile' + tileId;

      if (document.getElementById(adTileId) !== null) {
        return;
      }

      var adTile = document.createElement('div');
      adTile.id = adTileId;
      adTile.className = 'ad__tile ad__tile--' + tileId;

      adPosition.appendChild(adTile);

      if (initRenderCall && typeof AdController !== 'undefined') {
        AdController.render(adTileId);
      }
    }

    if (mobileTileId) {
      if (mobileTileId !== 'disabled') {
        if (window.mqIdent === 'mobile') {
          createAdTile(mobileTileId, mobileInitRenderCall);
        } else if (desktopTileId !== '') {
          createAdTile(desktopTileId, desktopInitRenderCall);
        }
      } else {
        if (window.mqIdent !== 'mobile') {
          createAdTile(desktopTileId, desktopInitRenderCall);
        }
      }
    } else {
      createAdTile(desktopTileId, desktopInitRenderCall);
    }
  }
</script>


  </head>
  <body class=" "  >
    
    
      
    

    
      
    
    <div class="apos-refreshable" data-apos-refreshable>
      
  
  <!-- Google Tag Manager (noscript) -->
  <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T4K79X"
  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
  <!-- End Google Tag Manager (noscript) -->

  <header class="document-header" id="document-header">
    

<div class="header__topbar">
  <div class="header__topbar__inner">
    <a class="szlabel" href="https://www.sueddeutsche.de/">
  <span class="szlabel__text">Partner von</span>
  <svg class="szlabel__ligeischahhhh" x="0" y="0" viewBox="0 0 1190.6 168">
      <g>
        <path d="M385.1,75.3l-36,31.1c3.1,8.2,15.9,16.4,28.6,1.7l4.8,5.2c-7.5,9.1-21.2,11.7-32.6,9.3c-10.3-2.2-18.6-11.9-21.4-21.7
  c-3.5-12.3-0.5-25.1,9.3-33.1C346.3,60.3,367.9,51.3,385.1,75.3L385.1,75.3z M374.7,75.7c-1.5-4.2-5.6-8.8-10.5-10.1
  c-4.2-1.3-9.1,0.3-12.8,3.5c-8.4,8.1-8.3,20.1-5,30.5L374.7,75.7L374.7,75.7z"/>
        <path d="M738.9,75.3l-36,31.1c3.1,8.2,15.9,16.4,28.6,1.7l4.8,5.2c-7.5,9.1-21.2,11.7-32.6,9.3c-10.3-2.2-18.6-11.9-21.4-21.7
  c-3.5-12.3-0.5-25.1,9.3-33.1C700.1,60.3,721.8,51.3,738.9,75.3L738.9,75.3z M728.5,75.7c-1.5-4.2-5.6-8.8-10.5-10.1
  c-4.2-1.3-9.1,0.3-12.8,3.5c-8.4,8.1-8.3,20.1-5,30.5L728.5,75.7L728.5,75.7z"/>
        <path d="M876.3,75.3l-36,31.1c3.1,8.2,15.9,16.4,28.6,1.7l4.8,5.2c-7.5,9.1-21.2,11.7-32.6,9.3c-10.3-2.2-18.6-11.9-21.4-21.7
  c-3.5-12.3-0.5-25.1,9.3-33.1C837.6,60.3,859.2,51.3,876.3,75.3L876.3,75.3z M866,75.7c-1.5-4.2-5.6-8.8-10.5-10.1
  c-4.2-1.3-9.1,0.3-12.8,3.5c-8.4,8.1-8.3,20.1-5,30.5L866,75.7L866,75.7z"/>
        <path d="M549.1,66.6c-0.2,0.3-4.7,6.4-4.7,6.4c-7.7-6-20.2-10.4-29.3-6.2c-6.8,3.4-5.5,11.1,4.2,13.7c6.3,2,27.1,3.8,29.4,19.4
  c0.8,6.4-2.2,12.1-7.3,16.1c-11.8,9-30.5,6.9-43.5,2.4c-0.1-0.2,3-10.3,3-10.3c4.1,2.7,7.6,4,11.6,5.5c20,7.2,31.5-5,19-12.2
  c-5.5-3.3-12.7-3.6-19.7-6.4c-5.2-2.1-10.6-6.1-12.3-11.9c-1.7-6-0.5-13,3.2-16.7C514.7,55.2,536.1,59.5,549.1,66.6L549.1,66.6z"/>
        <path d="M125.2,47.4c0-4.5,3.6-8.1,8.1-8.1c4.5,0,8.1,3.6,8.1,8.1c0,4.5-3.6,8.1-8.1,8.1C128.8,55.4,125.2,51.8,125.2,47.4
  L125.2,47.4z"/>
        <path d="M781.6,115.3c12.4,0.5,26.6-2,38.1-4.6c-0.5,0.9-4,9.2-4,9.2h-56.7L798.2,31c-4.1,0-12.2,0.1-12.2,0.1
  c-15.5,0-20.7,2-34.6,10.5l1-16.2H820L781.6,115.3z"/>
        <path d="M632.5,48.9v24.7c9.2-8.3,22.3-17,34.6-10.8c8.1,5.1,7,14.3,6.8,24.1c-0.3,15.7-1.2,32.9-1.2,32.9l-15.5,0
  c0.5-20.3,0.6-35.3-0.5-41.7c-0.6-3-1.3-6.1-4.6-7.6c-7.4-2.9-14.4,4-19.4,9.4v39.8h-17.5V53.5h-6.4v-4.6H632.5z"/>
        <path d="M934.6,64.8l1,55.1h-17.4l0.8-55.1h-10.9v-4.6H919v-2.5c0,0,4.2-1.6,7.8-3.3c5-2.3,7.8-4.4,7.8-4.4v10.1h34.7l0,0
  c0,0-3.9,38.6,0.6,49.7c1.1,2.8,3.7,4,6.8,3.3c5.9-1.6,11.6-5.5,16.5-9.7V64.8h-9.2v-4.6h26.6v59.7h-17.5v-9.2
  c-3,1.5-27.3,17.5-36.6,7.9c-5.5-6.1-5.7-17.3-6-27.1c-0.2-9,1.5-18.2,2.3-26.8H934.6z"/>
        <path d="M138.7,60.2c0,0-3.9,38.6,0.6,49.7c1.1,2.8,3.7,4,6.8,3.3c5.9-1.6,11.6-5.5,16.5-9.7V64.8h-9.2v-4.6H180v59.7h-17.5v-9.2
  c-3,1.5-27.3,17.5-36.6,7.9c-5.5-6.1-5.7-17.3-6-27.1c-0.2-9,1.5-18.2,2.3-26.8h-8.9l0-4.6L138.7,60.2L138.7,60.2z"/>
        <path d="M411.2,60.2c0,0-3.9,38.6,0.6,49.7c1.1,2.8,3.7,4,6.8,3.3c5.9-1.6,11.6-5.5,16.5-9.7V64.8h-9.2v-4.6h26.6v59.7h-17.5v-9.2
  c-3,1.5-27.3,17.5-36.6,7.9c-5.5-6.1-5.7-17.3-6-27.1c-0.2-9,1.5-18.2,2.3-26.8h-8.9l0-4.6L411.2,60.2L411.2,60.2z"/>
        <path d="M161.8,47.4c0-4.5,3.6-8.1,8.1-8.1c4.5,0,8.1,3.6,8.1,8.1c0,4.5-3.6,8.1-8.1,8.1C165.4,55.4,161.8,51.8,161.8,47.4
  L161.8,47.4z"/>
        <g>
          <polygon points="902.3,60.2 902.3,119.9 884.9,119.9 884.9,64.8 876.1,64.8 876.1,60.2 		"/>
          <path d="M885.4,47.4c0-4.5,3.6-8.1,8.1-8.1c4.5,0,8.1,3.6,8.1,8.1c0,4.5-3.6,8.1-8.1,8.1C889,55.4,885.4,51.8,885.4,47.4
    L885.4,47.4z"/>
        </g>
        <path d="M486.2,60.2h12.2v4.6h-12.2l1,55.1h-17.4l0.8-55.1h-12.2v-4.6h12.2v-2.5c0,0,4.2-1.6,7.8-3.3c5-2.3,7.8-4.4,7.8-4.4V60.2z"
          />
        <path d="M605.8,67.9l-3.5,5.1c-4.8-6.8-14.6-9-20.1-6c-11,6.4-11,21.4-9,33.3c1.4,6.7,5.8,14.7,13.1,15.9
  c5.7,0.8,11.8-3.3,14.1-5.4l5.7,6.3c0,0-3.4,2.6-7.3,3.7c-11.1,3.9-24.1,2.3-32.6-5.5c-9.1-8.4-12.4-19.4-10.2-31.2
  c1.8-10.1,11.3-19.6,21.1-22.3C586.8,59.2,598.5,61.3,605.8,67.9L605.8,67.9z"/>
        <path d="M227,48.9v4.6h5.9v15.7c0,0-11.7-13.4-29.4-4.1c-10.6,6.3-15,17.6-13.8,29.2c0.8,10.4,6,21.1,16.2,25.3
  c9.5,3.5,20.1,0.3,26.9-6.4v6.8H249v-71H227z M233.6,90.8c0,0-0.8,23.5-14.1,23.5c-13.3,0-12.8-23.6-12.8-23.6s0.2-22.2,14.1-22.2
  C234.6,68.5,233.6,90.8,233.6,90.8z"/>
        <path d="M295.4,48.9v4.6h5.9v15.7c0,0-11.7-13.4-29.4-4.1c-10.6,6.3-15,17.6-13.8,29.2c0.8,10.4,6,21.1,16.2,25.3
  c9.5,3.5,20.1,0.3,26.9-6.4v6.8h16.1v-71H295.4z M302.1,90.8c0,0-0.8,23.5-14.1,23.5c-13.3,0-12.8-23.6-12.8-23.6
  s0.2-22.2,14.1-22.2C303.1,68.5,302.1,90.8,302.1,90.8z"/>
        <path d="M1085.7,86c0.1,10.6,0.2,20.8-0.2,33.8c-5.2,0-17.1,0-17.1,0c1.1-13.8,5.6-46.1-6-48.6c-7.4-1.6-14.2,4-19.4,9.7v38.9
  h-16.9V64.8h-6.7v-4.6h23.5v13.9c8.1-7.7,18.9-16.1,30.2-13.8C1076.5,61,1085.4,63.5,1085.7,86z"/>
        <path d="M108.8,38.3l6.1-5.1l2.8,2.6l-14,11.9c-13.5-10.3-31.2-19.5-49-14.5c-4.6,1.5-10.8,5.5-11,11.3C43.5,54.9,64,60.2,64,60.2
  s27.5,8.4,38.8,19c5.2,4.7,6.9,12.3,5.5,19.8c-8.6,36.9-59.5,19-71.7,9l-6.3,6.4l-2.8-2.5l14.2-14.4c11.3,8.4,13.8,9.9,24.2,14.3
  c26.9,10.1,35.7-5.5,28.3-15.4C81.7,81.7,60.4,84.2,45.3,73.7C37.3,68,31.6,59.6,33,49.5c0.9-9.6,10.8-18.2,19.3-21.4
  C71.6,20.5,93.3,26.6,108.8,38.3L108.8,38.3z"/>
        <path d="M1167.9,69.8c0-4.4-3.6-8-8-8c-3.3,0-6.2,2-7.4,4.9c0,0-1,2.4-0.8,4.8c-0.4-0.7-2.2-2.4-3.3-3.3c-10-8.6-26.5-9.8-38-4
  c-12.4,6.4-18.8,19.3-17,33.1c1.1,11.6,11.5,22.4,22,26c-1.8,0.8-7.1,2-7.4,8.2c-0.2,10.6,16.7,5,25,7.9c2.1,1.1,3.2,3.2,2.8,5.7
  c-0.6,2-2.4,3.5-4.3,4.1c-7.8,2.6-15.9-1.7-21.5-7l-6,4.7c3.6,2.9,7.2,5.6,11.2,7c6.9,2.6,22.9,3.8,30.3-6.6
  c1.6-2.1,2.2-6.6,0.7-9.3c-5.5-9.2-18.1-4.9-25.5-5.9c-4.1-0.5-7-6.6,7.9-7.8c11.3-0.5,21.7-7.1,27.6-17.2
  c4.9-8.6,3.5-21.3-0.2-29.7c1.8,0.4,3.1,0.6,4.2,0.4C1164.5,77.6,1167.9,74.1,1167.9,69.8z M1126.4,118.4c-9.1,0-16.4-11.6-16.4-26
  c0-14.3,7.4-26,16.4-26c9.1,0,16.4,11.6,16.4,26C1142.8,106.8,1135.5,118.4,1126.4,118.4z"/>
      </g>
  </svg>
</a>

  </div>
</div>
<div class="header__wrapper">
  <div class="header__inner">
    
    <a class="header__logolink" href="/" aria-label="Zur Startseite">
  <svg class="header__logo" x="0" y="0" viewBox="90.979 96.498 274.615 151.08">
    <g class="header__logotext">
      <polyline points="103.891,96.557 103.891,114.867 125.887,114.867 125.887,114.867 125.887,96.557" />
      <path d="M103.891,122.219v96.744c0,5.935-3.49,8.726-12.912,8.726v19.367c2.443,0.351,5.234,0.522,8.025,0.522 c14.656,0,26.871-7.676,26.871-25.822v-99.536L103.891,122.219L103.891,122.219z" />
      <path d="M203.773,171.854v-22.16c0-19.369-14.482-32.279-34.898-32.279c-20.938,0-34.896,12.91-34.896,33.674v31.059 c0,20.764,13.959,33.676,34.896,33.676c22.16,0,33.852-11.516,34.898-31.059h-21.986c0,7.328-3.664,13.262-12.912,13.262 c-7.328,0-12.912-4.188-12.912-13.609v-12.562h47.81V171.854z M155.963,154.055v-5.234c0-8.375,4.014-13.609,12.912-13.609 s12.912,5.234,12.912,13.609v5.234H155.963L155.963,154.055z" />
      <path d="M212.049,96.498v100.039l0,0c0,13.609,9.422,18.844,23.73,18.844c4.188,0,8.375-0.174,12.562-0.873v-18.493 c-1.396,0.174-2.791,0.174-4.36,0.174c-5.935,0-9.944-2.269-9.944-6.979v-48.578h14.133v-18.309h-14.133V96.498" />
      <polygon points="256.116,140.631 295.303,140.631 255.917,196.255 255.917,214.078 322.348,214.078 322.348,195.908 282.043,195.908 322.348,139.791 322.348,122.322 256.116,122.322" />
      <path d="M329.193,96.498v100.039l0,0c0,13.609,9.423,18.844,23.729,18.844c4.188,0,8.375-0.174,12.562-0.873v-18.493 c-1.396,0.174-2.791,0.174-4.361,0.174c-5.934,0-9.944-2.269-9.944-6.979v-48.578h14.133v-18.309H351.18V96.498" />
    </g>
    <line class="header__logounderline colorScheme2" stroke="currentColor" stroke-width="14" x1="133.674" y1="231.324" x2="365.594" y2="231.324" />
  </svg>
</a>

    <div class="header__actions"></div>
  </div>
  <nav class="header__navigation">
    <div class="header__navigation-wrapper" id="header-navigation-control">
      <ul class="header__navigation-list header__navigation-list--tags" id="tagnavigation">

  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/politik"
    >
      Politik
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/aufsteigerinnen"
    >
      Aufsteigerinnen
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/liebe-und-beziehung"
    >
      Liebe und Beziehung
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/coronavirus"
    >
      Coronavirus
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/sex-auf-arabisch"
    >
      Sex auf Arabisch
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/umwelt"
    >
      Nachhaltigkeit
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="https://www.jetzt.de/digital/jetzt-auf-tiktok" 
      target="_blank" 
      rel="noopener"
    >
      jetzt auf Tiktok
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/rassismus"
    >
      Rassismus
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/the-female-gaze"
    >
      The Female Gaze
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/querfragen"
    >
      Querfragen
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/whatsapp-kolumne"
    >
      Whatsapp-Kolumne
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/sex"
    >
      Sex
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/corona-frei"
    >
      Corona-Frei
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/podcast-querfragen"
    >
      Podcast Querfragen
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/job"
    >
      Job
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/newsletter"
    >
      jetzt-Newsletter
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/studium"
    >
      Studium
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/zyklus-kolumne"
    >
      Zyklus-Kolumne
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/meine-theorie"
    >
      Meine Theorie
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/glotzen"
    >
      Glotzen
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/kultur"
    >
      Kultur
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/digital"
    >
      Digital
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/gesundheit"
    >
      Gesundheit
    </a>
    
  </li>
  
  <li class="header__navigation-listitem">
    
    <a 
      class="link header__navigation-listitem-link" 
      href="/tag/gutes-leben"
    >
      Tipps fürs Gute Leben
    </a>
    
  </li>
  

</ul>

    </div>
    <div class="header__navigation__burger">
      
<a class="header__navigation-burger" href="#burger" aria-expanded="false" aria-controls="tagnavigation" aria-label="Alle Themen">
  <span class="header__navigation-burgericon"></span>
</a>


    </div>
  </nav>
</div>

<button class="new-articles-hint">
  Neue Beiträge
</button>
  </header>
  <div id="saved-articles" class="offcanvas saved-article-view" role="dialog" aria-modal="true" aria-label="Merkliste">
    <div class="offcanvas-content">
      <p class="offcanvas-title">
        <span class="saved-article-view-count"></span> Artikel
      </p>
      <ol class="article-list article-list--saved"></ol>
    </div>
    <button class="offcanvas-close offcanvas-close-saved" aria-controls="saved-articles">X</button>
  </div>
    <div id="pushed-articles" class="offcanvas pushed-article-view" role="dialog" aria-modal="true" aria-label="Push-Nachrichten">
      <div class="offcanvas-content">
        
  <div class="offcanvas-header">
    <p>Push-Nachrichten erhalten</p>
    <label class="switch">
      <input type="checkbox" id="push-notification-permission" />
      <span class="slider"></span>
    </label>
  </div>
  <p class="offcanvas-title">
    
      Unsere interessantesten Artikel
    
  </p>
  
    <div class="notification-permission--granted">
      <p class="offcanvas-article-list-teaser">
        Derzeit sind noch keine Artikel verfügbar.
      </p>
    </div>
  
    <div class="notification-permission--new">
      <span class="offcanvas-list-action">Als gelesen markieren</span>
      <ol class="article-list article-list--pushed"></ol>
    </div>
  
    <div class="notification-permission--disabled">
      <p class="offcanvas-article-list-teaser">
        Sobald du unsere Push-Nachrichten aktivierst, erhältst Du hier einen Überblick neuer Artikel seit deinem letzten Besuch.
      </p>
    </div>
    <div class="notification-permission--denied">
      <p class="offcanvas-article-list-teaser">
        Bitte im Browser aktivieren.
      </p>
    </div>
  

      </div>
      <a href="#" class="offcanvas-close offcanvas-close-pushed" aria-controls="pushed-articles">X</a>
    </div>
  <main class="document-main">
    <div class="document-main__container">

    
      <!-- IQD: OOP / P1 / P2 -->
<div class="ad" id="iqd_mainAd" >
  <div id="iqd_align_Ad">
    <div id="iqd_topAd">
      <!-- BEGIN ad tag (iqadtileOOP) -->
      




<div id="ad__template--OOP" class="ad__template"></div>

<script>
  createAd('OOP', true, '', true);
</script>

      <!-- END ad tag (iqadtileOOP) -->
      <!-- BEGIN ad tag (iqadtile1) -->
      




<div id="ad__template--1" class="ad__template"></div>

<script>
  createAd('1', true, '', true);
</script>

      <!-- END ad tag (iqadtile1) -->
      <div id="iqd_rightAd">
        <!-- BEGIN ad tag (iqadtile2) -->
        




<div id="ad__template--2" class="ad__template"></div>

<script>
  createAd('2', true, '', true);
</script>

        <!-- END ad tag (iqadtile2) -->
      </div>
    </div>
  </div>
</div>

    

      
      
      
  <article class="article">
    <div class="article__container">
      <header class="article__header">
        <h1 class="article__header-title">Leider gibt es die von dir gesuchte Seite nicht - oder nicht mehr.</h1>
        <div class="article__header-teaser"></div>
      </header>

      <div class="article__content">
        <div class="apos-rich-text">
          <p>Aber vielleicht findest du ja unten auf unserer Startseite etwas anderes, das dich interessiert.<br />Wenn du den Fehler melden möchtest, kannst du uns <a href="mailto:info@jetzt.de">hier schreiben</a>.</p>
        </div>
      </div>
    </div>
  </article>

  
<div class="homepage-button-container">
  <a href="/" class="link link__button link__button--backlink homepage-button-container__link">Zur Startseite</a>
</div>


      
      
    </div>
  </main>
  <footer class="document-footer">
    <div class="logo">
    <a class="header__logolink" href="/" aria-label="Zur Startseite">
  <svg class="header__logo" x="0" y="0" viewBox="90.979 96.498 274.615 151.08">
    <g class="header__logotext">
      <polyline points="103.891,96.557 103.891,114.867 125.887,114.867 125.887,114.867 125.887,96.557" />
      <path d="M103.891,122.219v96.744c0,5.935-3.49,8.726-12.912,8.726v19.367c2.443,0.351,5.234,0.522,8.025,0.522 c14.656,0,26.871-7.676,26.871-25.822v-99.536L103.891,122.219L103.891,122.219z" />
      <path d="M203.773,171.854v-22.16c0-19.369-14.482-32.279-34.898-32.279c-20.938,0-34.896,12.91-34.896,33.674v31.059 c0,20.764,13.959,33.676,34.896,33.676c22.16,0,33.852-11.516,34.898-31.059h-21.986c0,7.328-3.664,13.262-12.912,13.262 c-7.328,0-12.912-4.188-12.912-13.609v-12.562h47.81V171.854z M155.963,154.055v-5.234c0-8.375,4.014-13.609,12.912-13.609 s12.912,5.234,12.912,13.609v5.234H155.963L155.963,154.055z" />
      <path d="M212.049,96.498v100.039l0,0c0,13.609,9.422,18.844,23.73,18.844c4.188,0,8.375-0.174,12.562-0.873v-18.493 c-1.396,0.174-2.791,0.174-4.36,0.174c-5.935,0-9.944-2.269-9.944-6.979v-48.578h14.133v-18.309h-14.133V96.498" />
      <polygon points="256.116,140.631 295.303,140.631 255.917,196.255 255.917,214.078 322.348,214.078 322.348,195.908 282.043,195.908 322.348,139.791 322.348,122.322 256.116,122.322" />
      <path d="M329.193,96.498v100.039l0,0c0,13.609,9.423,18.844,23.729,18.844c4.188,0,8.375-0.174,12.562-0.873v-18.493 c-1.396,0.174-2.791,0.174-4.361,0.174c-5.934,0-9.944-2.269-9.944-6.979v-48.578h14.133v-18.309H351.18V96.498" />
    </g>
    <line class="header__logounderline colorScheme2" stroke="currentColor" stroke-width="14" x1="133.674" y1="231.324" x2="365.594" y2="231.324" />
  </svg>
</a>

</div>


<div class="social-channels">
    <p>
        Folge uns auf folgenden Kanälen:
    </p>
    <ul>
        <li>
            <a href="https://www.instagram.com/jetzt_de/" aria-label="Folge uns auf Instagram" target="_blank" rel="noopener"><span class="icon--wrapper icon--instagram">
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" viewBox="0 0 19.3 19.24">
      <path d="M17.5,13.55c-0.04,0.94-0.2,1.45-0.33,1.79c-0.32,0.84-0.99,1.5-1.83,1.83c-0.34,0.13-0.85,0.29-1.79,0.33c-1.02,0.05-1.32,0.06-3.9,0.06c-2.57,0-2.88-0.01-3.9-0.06c-0.94-0.04-1.45-0.2-1.79-0.33c-0.42-0.15-0.8-0.4-1.11-0.72c-0.32-0.31-0.57-0.69-0.72-1.11C2,15,1.84,14.49,1.8,13.55c-0.05-1.02-0.06-1.32-0.06-3.89c0-2.57,0.01-2.88,0.06-3.89C1.84,4.83,2,4.32,2.13,3.98c0.15-0.42,0.4-0.8,0.72-1.11c0.31-0.32,0.69-0.56,1.11-0.72C4.3,2.03,4.82,1.87,5.76,1.83c1.02-0.05,1.32-0.06,3.9-0.06c2.58,0,2.88,0.01,3.9,0.06c0.94,0.04,1.45,0.2,1.79,0.33c0.42,0.15,0.8,0.4,1.11,0.72c0.32,0.31,0.57,0.69,0.72,1.11c0.13,0.34,0.29,0.85,0.33,1.79c0.05,1.02,0.06,1.32,0.06,3.89C17.56,12.23,17.55,12.53,17.5,13.55z M19.24,5.68c-0.05-1.02-0.21-1.73-0.45-2.34c-0.25-0.65-0.62-1.23-1.12-1.71c-0.48-0.49-1.07-0.87-1.71-1.11c-0.61-0.24-1.32-0.4-2.34-0.45c-1.03-0.05-1.36-0.06-3.98-0.06c-2.62,0-2.95,0.01-3.98,0.06C4.64,0.12,3.94,0.29,3.33,0.53C2.68,0.77,2.1,1.15,1.62,1.64C1.13,2.12,0.75,2.7,0.51,3.34C0.27,3.96,0.1,4.66,0.06,5.68C0.01,6.71,0,7.04,0,9.65c0,2.61,0.01,2.94,0.06,3.97c0.05,1.02,0.21,1.73,0.45,2.34c0.25,0.65,0.63,1.23,1.12,1.71c0.48,0.49,1.07,0.87,1.71,1.11c0.61,0.24,1.32,0.4,2.34,0.45c1.03,0.05,1.36,0.06,3.98,0.06s2.95-0.01,3.98-0.06c1.03-0.05,1.73-0.21,2.34-0.45c1.3-0.5,2.32-1.52,2.82-2.82c0.24-0.61,0.4-1.31,0.45-2.34c0.05-1.03,0.06-1.35,0.06-3.97C19.29,7.04,19.29,6.71,19.24,5.68z" />
      <path d="M9.27,13.14c-1.73,0-3.13-1.4-3.13-3.12c0-1.72,1.4-3.12,3.13-3.12c1.73,0,3.13,1.4,3.13,3.12
	C12.4,11.75,11,13.14,9.27,13.14z M9.27,5.21c-2.66,0-4.82,2.16-4.82,4.81c0,2.66,2.16,4.81,4.82,4.81c2.66,0,4.82-2.16,4.82-4.81
	C14.09,7.36,11.93,5.21,9.27,5.21z" />
      <path d="M15.58,4.84c0,0.61-0.5,1.11-1.11,1.11c-0.61,0-1.11-0.5-1.11-1.11c0-0.61,0.5-1.11,1.11-1.11
	C15.08,3.73,15.58,4.22,15.58,4.84z" />
    </svg>
  </span></a>
        </li>
        <li>
            <a href="https://www.facebook.com/jetzt.de/" aria-label="Folge uns auf Facebook" target="_blank" rel="noopener"><span class="icon--wrapper icon--facebook">
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" viewBox="0 0 9.94 19.24">
      <path d="M9.8,6.89H6.27V5.17c0,0-0.2-1.63,0.95-1.63c1.29,0,2.33,0,2.33,0V0.01H5.58c0,0-3.32-0.01-3.32,3.31c0,0.71,0,2.01-0.01,3.57h-2.27v2.84h2.27c-0.01,4.51-0.03,9.54-0.03,9.54h4.05V9.73h2.67L9.8,6.89z" />
    </svg>
  </span></a>
        </li>
        <li>
            <a href="https://twitter.com/jetzt/" aria-label="Folge uns auf Twitter" target="_blank" rel="noopener"><span class="icon--wrapper icon--twitter">
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" viewBox="0 0 18.57 16.15">
      <path d="M18.46,2.78c-0.11-0.18-0.31-0.28-0.52-0.26L17.01,2.6l0.88-1.78c0.11-0.21,0.06-0.47-0.1-0.63c-0.17-0.17-0.42-0.21-0.64-0.11l-2.34,1.14c-1.45-0.76-3.25-0.54-4.49,0.59C9.29,2.76,8.74,4.21,8.84,5.66C6.13,5.39,3.84,3.84,2.48,1.33C2.39,1.17,2.22,1.06,2.03,1.04C1.84,1.03,1.66,1.12,1.55,1.27C0.71,2.4,0.65,3.96,1.31,5.24C1.12,5.19,0.93,5.13,0.72,5.06C0.53,5,0.33,5.04,0.18,5.16C0.03,5.29-0.04,5.48-0.01,5.67c0.26,1.58,1.18,2.79,2.64,3.51C2.45,9.25,2.25,9.31,2.06,9.35C1.86,9.39,1.7,9.53,1.64,9.72c-0.06,0.19-0.01,0.4,0.12,0.54c1.05,1.12,2.57,1.67,3.64,1.94c-1.22,0.96-2.55,1.12-4.47,1.05c-0.22-0.01-0.43,0.12-0.52,0.32c-0.09,0.2-0.06,0.44,0.09,0.6c0.8,0.88,3.72,1.88,6.79,1.95c0.12,0,0.25,0,0.37,0c2.15,0,5-0.46,7.04-2.5c1.55-1.54,2.51-3.32,2.88-5.28c0.29-1.58,0.11-2.85,0.02-3.46c-0.01-0.04-0.01-0.09-0.02-0.13l0.87-1.39C18.57,3.18,18.57,2.96,18.46,2.78z" />
    </svg>
  </span></a>
        </li>
        <li>
            <a href="/newsletter" aria-label="Bestelle unseren Email-Newsletter"><span class="icon--wrapper icon--mail">
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" viewBox="0 0 24 19">
      <path d="M9 9.3l2.4 2.2c.1.1.3.2.5.2s.4-.1.5-.2l2.4-2.2 7.6 9-7.6-9 8.6-7.9c.3.5.5 1.1.5 1.7v12.5c0 .5 0 1.9-1.4 2.7-.5.3-1 .5-1.6.5H3c-.7-.1-1-.1-1.6-.4C0 18.1 0 16.2 0 15.7V3.1c0-.6.2-1.2.5-1.7L9 9.3zm2.9.6L1.5.4C2 .2 2.5 0 3 0h17.9c.5 0 1 .2 1.4.4L11.9 9.9z"/>
    </svg>
  </span></a>
        </li>
        <li>
            <a href="/whatsapp" aria-label="Bestelle unseren WhatsApp-Newsletter"><span class="icon--wrapper icon--whatsapp">
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" viewBox="0 0 23 23"><path d="M23 11.2c0 6.2-5.1 11.2-11.3 11.2-2 0-3.8-.5-5.5-1.4L0 23l2-6C1 15.3.4 13.3.4 11.2.4 5 5.5 0 11.7 0 17.9 0 23 5 23 11.2zm-4 3.4c-.1-.1-.3-.2-.7-.4-.3-.2-2-1-2.4-1.1-.3-.1-.5-.2-.8.2-.2.3-.9 1.1-1.1 1.3-.2.2-.4.3-.7.1-.3-.2-1.5-.5-2.8-1.7-1-.9-1.7-2-1.9-2.4-.2-.3 0-.5.2-.7.2-.2.3-.4.5-.6.2-.2.2-.3.3-.5.1-.2.1-.4 0-.6-.1-.2-.8-1.9-1-2.6-.3-.7-.6-.6-.8-.6h-.7c-.3 0-.6.1-.9.4C5.9 5.8 5 6.6 5 8.3s1.2 3.3 1.4 3.5c.2.2 2.4 3.8 5.9 5.2 3.5 1.4 3.5.9 4.1.9.6-.1 2-.8 2.3-1.6.3-.9.3-1.5.3-1.7z"/></svg>
  </span></a>
        </li>
        <li>
            <a href="https://www.tiktok.com/@jetzt.de" aria-label="Folge uns auf TikTok" target="_blank" rel="noopener"><span class="icon--wrapper icon--tiktok">
    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="23" height="26" viewBox="0 0 23 26" fill="none">
      <path d="M9.34863 9.68256V14.1513C8.78629 14.003 8.19785 13.9828 7.62666 14.0921C7.05547 14.2014 6.51609 14.4375 6.04828 14.783C5.58046 15.1285 5.19613 15.5746 4.9236 16.0883C4.65108 16.6021 4.49731 17.1704 4.47363 17.7515C4.44163 18.2518 4.51708 18.7532 4.69492 19.2219C4.87275 19.6907 5.14885 20.1159 5.50466 20.4691C5.86046 20.8223 6.28774 21.0953 6.75778 21.2696C7.22783 21.444 7.72974 21.5158 8.22981 21.4801C11.0053 21.4801 11.986 19.5301 11.986 17.7011V0H16.4044C17.1559 4.67431 19.4919 5.759 22.6233 6.26031V10.7388C22.6233 10.7388 18.9085 10.4747 16.5295 8.68075V17.5281C16.5271 21.5312 14.1538 26 8.26313 26C2.79663 26 0 21.3687 0 17.4866C0.0348554 16.3364 0.313144 15.2067 0.816513 14.1719C1.31988 13.1371 2.0369 12.2208 2.92027 11.4834C3.80365 10.746 4.83332 10.2042 5.94138 9.89378C7.04944 9.58337 8.21071 9.51138 9.34863 9.68256V9.68256Z" fill="#29293A"/>
    </svg>
  </span></a>
        </li>
    </ul>
</div>
<div class="copyright-privacy">
    <ul class="copyright">
  <li>
    <a href="https://sz.de/copyright" class="copyright__link">&copy; SZ</a>
  </li>
  <li>
    <a href="/impressum" class="copyright__link">Kontakt und Impressum</a>
  </li>
  <li>
    <a href="/agb" class="copyright__link">AGB</a>
  </li>
</ul>

    <ul class="privacy">
  
  <li>
    <a href="/datenschutz" class="copyright__link">Datenschutz</a>
  </li>
  
  
  <li>
    <a href="#" onclick="window._sp_.loadPrivacyManagerModal(186043); return false;" class="copyright__link">Datenschutz-Einstellungen</a>
  </li>
  
</ul>

</div>

  </footer>

    </div>
    <script>
window.apos = {"prefix":"","csrfCookieName":"pegasus.csrf","uploadsUrl":"https://caching-production.jetzt.de"}
</script>
<script src="https://caching-production.jetzt.de/assets/ckghrc6290001c1y7qgrzbub7/apos-minified/anon-ckghrc6290001c1y7qgrzbub7.js"></script>

    
      <script type="text/javascript">
        
        
      </script>
    
    
    
  <script>
  if (typeof AdController !== 'undefined') {
    AdController.finalize();
  }
</script>
<div id="iqdCheckPointHight">
  <script>
    var IQDComplete = {
      init: function() {
        return true;
      }
    }
  </script>
</div>


  </body>
</html>
